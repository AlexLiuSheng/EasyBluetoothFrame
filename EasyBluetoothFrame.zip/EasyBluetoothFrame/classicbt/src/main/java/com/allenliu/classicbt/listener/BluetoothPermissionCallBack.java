package com.allenliu.classicbt.listener;

/**
 * @author AllenLiu
 * @version 1.0
 * @date 2019/5/27

 */
public interface BluetoothPermissionCallBack {
    void onBlueToothEnabled();
    void permissionFailed();
}
