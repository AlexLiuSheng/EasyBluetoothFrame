package com.allenliu.classicbt;

import android.util.Log;

/**
 * @author AllenLiu
 * @version 1.0
 * @date 2019/5/20

 */
public class CLog {
    public static void e(String message){
        Log.e("classicbt",message);
    }
}
